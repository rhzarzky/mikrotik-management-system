<script setup>
</script>

<template>
  <VApp>
    <RouterView />
  </VApp>
</template>
