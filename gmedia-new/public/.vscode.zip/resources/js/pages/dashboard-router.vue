<script setup>
import Graph from '@/views/dashboard-router/Graph.vue'
</script>

<template>
  <VRow>

    <VCol cols="12">
        <VCard title="Interface">
          <VCardText>
            <Graph />
          </VCardText>
        </VCard>
    </VCol>
 
    
  </VRow>
</template>
